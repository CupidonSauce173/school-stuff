# Entrée
limite = int(input())

# Sorties. À faire
i = 0
while i <= limite:
    print(i)
    i += 2
# end while
