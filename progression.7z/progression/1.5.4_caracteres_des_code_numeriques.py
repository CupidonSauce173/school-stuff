# Entrées
code_min = int(input())
code_max = int(input())

# Sorties. À faire
while code_min <= code_max:
    print(chr(code_min))
    code_min += 1
# end while
