MAX = 10
compteur = 0

# Entrée
mot = input()

# Sorties. À faire
while compteur < MAX:
    print(mot, end="")
    compteur += 1
# end while
