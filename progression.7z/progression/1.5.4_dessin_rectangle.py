# Entrées
largeur = int(input())
longueur = int(input())
caractère = input()

# Sortie du rectangle. À faire
i = 0
while i < largeur:
    print(caractère * longueur)
    i += 1
# end while
