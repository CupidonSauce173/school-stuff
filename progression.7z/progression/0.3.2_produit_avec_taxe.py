TAUX = 15

# Entrée de la quantité
quantité = int(input())
# Entrée du prix. À faire
prix = float ( input() )

# Calcul et Sortie. À faire
montant = quantité * prix
montant = (montant * 0.15) + montant

print(montant)
