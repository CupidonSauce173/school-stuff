MAX = 10

# Sorties. À faire
for i in range( 10 ):
    print( "Bonjour" )
# end for
