nom = 'Bob'
âge = 18

print("Bonjour, je m'appelle", nom, "et j'ai", âge, "ans!")
