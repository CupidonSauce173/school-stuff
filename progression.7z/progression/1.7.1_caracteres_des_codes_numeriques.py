# Entrées
code_min = int( input() )
code_max = int( input() )

# Sorties. À faire
for i in range(code_min, code_max + 1):
    print(chr(i))
# end for
